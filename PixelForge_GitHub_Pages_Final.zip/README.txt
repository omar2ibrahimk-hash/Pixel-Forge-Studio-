PIXELFORGE STUDIO — GITHUB PAGES EDITION

This is a static website. It does not contain an AI option or require Node.js.

PUBLISH ON GITHUB PAGES
1. Create or open your GitHub repository.
2. Upload index.html to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Choose the main branch and / (root), then Save.
6. Wait for GitHub Pages to publish your site.

FEATURES
- Editable starter templates
- Drag-and-drop text and shapes
- Image uploads
- Multiple pages
- Save/open project JSON in the browser
- Basic PNG export

NOTES
- Projects are saved in this browser unless exported as a project file.
- This is a lightweight starter editor, not a complete Canva replacement.
